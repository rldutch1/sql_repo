<?php
include_once('connect_pdo.php');
//$queryt = $handler->query('call termlist');
//$queryt = $handler->query('select code_value, code_set, display, display_key, filename, filename_id from iview_code_value1 order by display_key;');
$queryt = $handler->query('select term, filename, ccl_name, code_snippet, filename_id, active_ind from iview_code_snippet1 order by term;');
$r = $queryt->fetch(PDO::FETCH_OBJ);
$s = $queryt->rowCount();
echo "<html><head><title></title></head><body>";
echo "<table>";
//echo "<tr><td>DROP TABLE IF EXISTS iview_code_value1;<br />
//CREATE TABLE iview_code_value1 (<br />
//  id int NOT NULL,<br />
//  code_value bigint NOT NULL,<br />
//  code_set int NOT NULL,<br />
//  display varchar(100) NOT NULL,<br />
//  display_key varchar(100) NOT NULL,<br />
//  filename varchar(100) NOT NULL DEFAULT 'noname',<br />
//  filename_id int NOT NULL DEFAULT '9999'<br />
//);</td></tr>";


//			while($r = $queryt->fetch(PDO::FETCH_OBJ)){
////			echo "<tr><td>insert into iview_code_value1 (code_value, code_set, display, display_key, filename, filename_id) values (</td><td>'" . $r->code_value . "',</td><td>'" . $r->code_set . "',</td><td>'" . htmlentities($r->display) . "',</td><td>'" . $r->display_key . "',</td><td>'" . $r->filename . "',</td><td>'" . $r->filename_id . "');</td></tr>";
//			echo "<tr><td>insert into iview_code_value1 (code_value, code_set, display, display_key, filename, filename_id) values ('" . $r->code_value . "','" . $r->code_set . "','" . htmlentities(str_replace("'","''",(str_replace('"','""',$r->display)))) . "','" . $r->display_key . "','" . $r->filename . "','" . $r->filename_id . "');</td><td>";
//			}

//echo "<tr></tr>";
echo "<tr><td>DROP TABLE IF EXISTS iview_code_snippet1;<br />
CREATE TABLE iview_code_snippet1 (<br />
  id int NOT NULL,<br />
  term varchar(100) DEFAULT NULL,<br />
  filename varchar(100) NOT NULL,<br />
  ccl_name varchar(100) NOT NULL,<br />
  code_snippet varchar(500) NOT NULL,<br />
  filename_id int NOT NULL DEFAULT '9999',<br />
  active_ind int NOT NULL DEFAULT '0'<br />
);<br /></td></tr>";

			while($r = $queryt->fetch(PDO::FETCH_OBJ)){
//			echo "<tr><td>insert into iview_code_snippet1 (code_value, code_set, display, display_key, filename, filename_id) values (</td><td>'" . $r->code_value . "',</td><td>'" . $r->code_set . "',</td><td>'" . htmlentities($r->display) . "',</td><td>'" . $r->display_key . "',</td><td>'" . $r->filename . "',</td><td>'" . $r->filename_id . "');</td></tr>";
echo "<tr><td>insert into iview_code_snippet1 (term, filename, ccl_name, code_snippet, filename_id, active_ind) values ('" . htmlentities(str_replace("'","''",(str_replace('"','""',$r->term)))) . "','" . $r->filename . "','" . $r->ccl_name . "','" . htmlentities(str_replace("'","''",(str_replace('"','""',$r->code_snippet)))) . "','" . $r->filename_id . "','" . $r->active_ind . "');</td><td>";
			}

echo "</table>";
echo"</body></html>";
?>

